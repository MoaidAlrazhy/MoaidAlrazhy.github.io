 /// <reference path="../typings/globals/jquery/index.d.ts" />


 $(document).ready(function () {
    var wow = new WOW().init();
 
 
    $('.main_slider').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: true,
      draggable: true,
      nextArrow: $('.slider-prev'),
      prevArrow: $('.slider-next'),
      draggable: false,
      swipe: false
 
    });
 
    $('.slider-next').click(function () {
      $(".animated_plane").animate({
        "left": "110%",
        "opacity": "1"
      }, 800);
      $(".animated_plane").animate({
        "left": "-10%",
        "opacity": "0"
      }, 0)
    });
 
 
    $('.slider-prev').click(function () {
      $(".animated_plane").animate({
        "left": "110%",
        "opacity": "1"
      }, 0);
      $(".animated_plane").animate({
        "left": "-10%",
        "opacity": "0"
      }, 800)
    });
 
    $(".slick_packages").slick({
      slidesToShow: $(".slick_packages .slide").length > 3 ? 3 : $(".slick_packages .slide").length == 1 ? 1 : $(".slick_packages .slide").length - 1,
      slidesToScroll: 1,
      centerMode: true,
      arrows: true,
      centerPadding: '0%',
      draggable: true,
      adaptiveHeight: true,
      focusOnSelect: true,
      asNavFor: '.slick_packages2',
      prevArrow: $('.slider-package-prev'),
      nextArrow: $('.slider-package-next'),
      responsive: [{
        breakpoint: 581,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
          centerPadding: "20%"
        }
      }]
    });
 
    $('.slick_packages2').slick({
      slidesToShow: 1,
      slidesToScroll: 1,
      arrows: false,
      fade: true,
      asNavFor: '.slick_packages'
    });
 
 
 
 
 
    $(".openPopUpMenu").on("click", function () {
      $(".pop-menu").toggle();
    });
 
 
 
 
    let firstGroupNavItems = $(".detach").eq(0).html();
    let secondGroupNavItems = $(".detach").eq(1).html();
    let thirdGroupNavItems = $(".detach").eq(2).html();
 
    function SwitchToSmallNav() {
      $(".detach").html("");
      $(".mobileNav").height($(window).height() - $("nav").height());
      $(".mobileNav").css("margin-top", $("nav").height());
      $(".mobileNavContent").html(firstGroupNavItems + '' + secondGroupNavItems + '' + thirdGroupNavItems);
    }
 
    function SwitchToLargeNav() {
 
      $(".detach").eq(0).html(firstGroupNavItems);
      $(".detach").eq(1).html(secondGroupNavItems);
      $(".detach").eq(2).html(thirdGroupNavItems);
 
 
      $(".mobileNavContent").html("");
      setTimeout(() => {
        $(".mobileNav").height(0);
      }, 300);
      $(".mobileNav").css("margin-top", 0);
 
    }
 
    let clicked = false;
    $(".humbugger-icon").on("click", function () {
 
      $(".menu-icon").first().toggleClass("menu-icon-first_animated");
      $(".menu-icon").last().toggleClass("menu-icon-last_animated");
 
      if (clicked) {
        $(".mobileNav").removeClass("slideInLeft").addClass("slideOutLeft").fadeOut("fast");
        SwitchToLargeNav();
        clicked = false;
 
      } else {
        $(".mobileNav").fadeIn("fast").addClass("slideInLeft").removeClass("slideOutLeft");
        SwitchToSmallNav();
        clicked = true;
      }
 
    });
 
 
    function manageNavWithHeight() {
 
      if ($(window).width() <= 700) {
        SwitchToSmallNav();
      } else {
        SwitchToLargeNav();
        $(".mobileNav").removeClass("slideInLeft").addClass("slideOutLeft").fadeOut("fast");
        clicked = false
        $(".menu-icon").first().removeClass("menu-icon-first_animated");
        $(".menu-icon").last().removeClass("menu-icon-last_animated");
 
 
      }
    }
 
 
 
 
    $(".hoverOnMe").hover(function () {
 
 
      $(this).find(".animated_vocation_element").animate({
        "top": $(this).find(".vocation_section_img").position().top + parseInt($(".vocation_section").css("padding-top")),
        "right": $(this).find(".vocation_section_img").position().left,
        "height": $(this).find(".vocation_section_img").height(),
        "width": $(this).find(".vocation_section_img").width(),
        
      }, 200, function () {
       
 
 
        $(this).css({
          "transform": "translate(0%,0%)",
        });
        $(this).find("img").css({
          "filter": " grayscale(0)",
        });
      });
 
 
      $(this).find(".vocation_heading").animate({
        "top": $(this).find(".vocation_title").position().top,
         "right": (($(window).width()/12)*5)+parseInt($(this).find(".vocation_title").parent().css("padding-right")),
          
      }, 200, function () {
 
        $(this).css({
          "transform": "translate(0%,0%)",
          "font-size": "calc(.5rem + 1.5vw)"
        })
      });
      $(this).find(".green_underline").css({
        "transform": "scaleX(25) scaleY(37)translateY(23%)",
        "border-radius": "0rem",
        "opacity": "0",
      }).delay(500).fadeOut();
      $(this).find(".vocation_text_with_button").addClass("fadeInRightBig").removeClass("fadeOutRightBig");
 
 
    }, function () {
 
      $(this).find(".animated_vocation_element").animate({
        "top": "50%",
        "right": "50%",
        "height": "130%",
        "width": "50%",
 
      }, 200, function () {
        $(this).css({
          "transform": "translate(50%,-50%)",
        });
        $(this).find("img").css({
          "filter": " grayscale(1)",
        });
 
      })
 
      $(this).find(".vocation_heading").animate({
        "top": "50%",
        "right": "50%",
 
      }, 200, function () {
        $(".vocation_heading").css({
          "transform": "translate(50%,-50%)",
          "font-size": "calc(.5rem + 3.5vw)"
        })
        $(".green_underline").show().css({
          "transform": "scaleX(1)scaleY(1)translateY(0%)",
          "border-radius": "1rem",
          "opacity": "1",
        })
      });
      if ($(window).width() > 990)
        $(this).find(".vocation_text_with_button").addClass("fadeOutRightBig").removeClass("fadeInRightBig");
 
    });
 
 
 
 
    if ($(window).width() <= 990) {
      $(".vocation_text_with_button").addClass("fadeInRightBig").removeClass("fadeOutRightBig");
    }
    window.onload = function () {
      $("#preloader").delay(100).fadeOut("slow");
 
      $(window).trigger("resize") // to solve slick responsive problem 
 
    }
 
    $(window).trigger("load");
    $(".request_back").height($(".request_content").height() - 100)
 
 
    //////////////////models /////////////////////////
 
    $(".close_request_modal").on("click", function () {
      $(".request_modal").fadeOut();
    })
 
    $(".open_request_modal").on("click", function () {
      $(".request_modal").fadeIn();
      $(".request_back").height($(".request_content").height() - 100)
    })
    $(".close_view_modal").on("click", function () {
      $(".view_modal").fadeOut();
    })
    $(".open_view_modal").on("click", function () {
      $(".view_modal").fadeIn();
    })
 
    function ManageMoreInfoModalHeight() {
      $(".more_info_modal").height($(window).height() - $("nav").height());
      $(".more_info_modal").css("margin-top", $("nav").height());
    }
 
    ManageMoreInfoModalHeight();
 
 
    $(".open_more_info_modal").on("click", function () {
      $(".more_info_modal").fadeIn();
    })
    $(".close_more_info_modal").on("click", function () {
      $(".more_info_modal").fadeOut();
    })
 
    $(".hideRequest_showCongrats").on("click", function () {
     $(".request_modal").fadeOut();
     $(".congrats_modal").fadeIn();
     $(".congrats_modal .congrats_back").removeClass("animated fadeOutDown").addClass("animated fadeInUp").fadeIn();
 
   })
 
   $(".close_congrats_modal").on("click", function () {
     $(".congrats_modal").fadeOut();
     $(".congrats_modal .congrats_back").removeClass("animated fadeInUp").addClass("animated fadeOutDown").fadeIn();
   })
    //////////////////////////////////////////////////////
 
 
 
 
 
 
 
 
    $(window).resize(function () {
      manageNavWithHeight();
      ManageMoreInfoModalHeight();
      if ($(".bg-plane-image").length)
        $(".bg-plane-image").css({
          "top": $(".getTop1").position().top,
        })
 
      if ($(window).width() <= 990) {
        $(".vocation_text_with_button").addClass("fadeInRightBig").removeClass("fadeOutRightBig");
 
      }
      $(".grid-item.size1").height($(".grid-item").width())
      $(".request_back").height($(".request_content").height() - 100)
    });
 
    function SortCards() {
 
      let index = 1;
      $(".grid-item").each(function () {
        if (
          index == 5 || index == 7 || index == 14 || index == 16 || index == 23 || index == 25 || index == 32 || index == 34 || index == 41 || index == 43 ||
          index == 50 || index == 52 || index == 59 || index == 61 || index == 68 || index == 70 || index == 77 || index == 79 || index == 86 || index == 88 ||
          index == 95 || index == 97 || index == 104 || index == 106 || index == 113 || index == 115 || index == 122 || index == 124 || index == 131 || index == 133
 
        ) {
          $(this).addClass("size2-2").removeClass("size1");
        }
        index++;
      })
 
      $(".grid-item.size1").height($(".grid-item").width())
 
    }
 
    SortCards();
 
    if ($(".bg-plane-image").length)
      $(".bg-plane-image").css({
        "top": $(".getTop1").position().top,
      });




  });